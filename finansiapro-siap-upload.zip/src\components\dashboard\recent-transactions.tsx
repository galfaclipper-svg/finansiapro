'use client';

import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardDescription,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { useAppState } from '@/hooks/use-app-state';
import { formatCurrency } from '@/lib/utils';
import { ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { Button } from '../ui/button';
import Link from 'next/link';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';

export function RecentTransactions() {
  const { transactions, dateRange } = useAppState();

  const filteredTransactions = transactions.filter(t => {
      if (!dateRange?.from || !dateRange?.to) return true;
      const transactionDate = new Date(t.date);
      const toDate = new Date(dateRange.to);
      toDate.setHours(23, 59, 59, 999);
      return transactionDate >= dateRange.from && transactionDate <= toDate;
  });

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div className="grid gap-2">
            <CardTitle>Transaksi Terkini</CardTitle>
            <CardDescription>
                Anda memiliki {filteredTransactions.length} transaksi di periode ini.
            </CardDescription>
        </div>
        <Button asChild size="sm" variant="outline">
            <Link href="/transactions">Lihat Semua</Link>
        </Button>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Deskripsi</TableHead>
              <TableHead className="hidden sm:table-cell">Kategori</TableHead>
              <TableHead className="hidden sm:table-cell">Tanggal</TableHead>
              <TableHead className="text-right">Jumlah</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredTransactions.slice(0, 5).map((transaction) => (
              <TableRow key={transaction.id}>
                <TableCell>
                  <div className="font-medium">{transaction.description}</div>
                </TableCell>
                <TableCell className="hidden sm:table-cell">
                  <Badge variant="outline">{transaction.category}</Badge>
                </TableCell>
                <TableCell className="hidden sm:table-cell">{format(new Date(transaction.date), 'd LLL y', { locale: id })}</TableCell>
                <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                        {transaction.type === 'cash-in' ? (
                            <ArrowUpRight className="h-4 w-4 text-green-500" />
                        ) : (
                            <ArrowDownLeft className="h-4 w-4 text-red-500" />
                        )}
                        {formatCurrency(transaction.amount)}
                    </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
